import configparser
import openai
import os

# application.properties 파일 경로 (프로젝트 구조에 맞게 조정)
PROPERTIES_FILE = os.path.join(os.path.dirname(__file__), '../../application.properties')

config = configparser.ConfigParser()
config.optionxform = str  # 키의 대소문자 유지
config.read(PROPERTIES_FILE)

# application.properties 파일에서 API 키 가져오기 (섹션 이름과 키를 실제 파일과 맞게 수정)
OPENAI_API_KEY = config.get("DEFAULT", "openai.api_key")
openai.api_key = OPENAI_API_KEY

def generate_chat_response(message: str):
    """
    OpenAI API를 호출하여 대화형 응답을 생성합니다.
    """
    prompt = f"다음 사용자 메시지에 대해 친절하고 상세하게 답변해줘:\n{message}"
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.8,
            max_tokens=150,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"오류 발생: {str(e)}"

# 필요에 따라 추가 함수들 (예: get_youtube_recommendations, get_recipe_recommendations, get_trending_menu)도 이 파일에 구현
